use master;
go
create database clinic90;
go
use clinic90
go
create schema Users
go
create table Users.staffs
(
staff_id int  primary key identity,
staff_name varchar(15) not null ,
staff_password varchar(4) not null,
staff_role varchar(50) not null,
staff_phone varchar(12),
salary int
)

alter table Users.staffs 
drop column salary  ;

alter table Users.staffs 
drop column staff_role;

create table Users.patients
(
patient_id int  primary key identity,
patient_name nvarchar(50) not null,
patient_age int not null,
patient_phone varchar(12),
patient_address varchar(15),
symptoms varchar(100) not null
)

go 

alter table Users.patients
add gender varchar (10);
go 

alter table Users.patients
 add patient_status varchar(15);
 go 

 alter table Users.patients
 add patient_notes varchar (150);
 go

alter table Users.patients
add "date" date;
go

alter table Users.patients
add "date" date ;
alter table Users.patients
add signs varchar(100) 

create schema appointments;
go
create table appointments.appointments
(
appointments_id int  primary key identity,
appointments_date date ,
appointments_status varchar(50) ,
appointments_reason varchar(500) not null
)
go
create schema session
go
create table session.diagnosises
(
diagnosis_id int  primary key identity,
diagnosis_date date ,
diagnose varchar(500) not null
)
go
create table session.persriptions
(
persription_id int  primary key identity,
persription_date date not null,
persription_quantity int , 
medication varchar(500) not null,
dosage int not null,
duration varchar(50) not null,
persription_note varchar(100) 
);
go


alter table appointments.appointments
add pat_id int


alter table appointments.appointments
add constraint fk_patients_appointments_id
foreign key(pat_id)references Users.patients(patient_id)
go


alter table appointments.appointments
add staf_id int
go


alter table appointments.appointments
add constraint fk_staffs_appointments_id
foreign key(staf_id)references Users.staffs(staff_id)
go


alter table appointments.appointments
add diagn_id int
go


alter table appointments.appointments
add constraint fk_diagnosises_appointments_id
foreign key(diagn_id) references session.diagnosises(diagnosis_id)
go

create table Users.patient_diagnosis
(
d_id int not null,
p_id int not null,
date_diag date
)
go


alter table Users.patient_diagnosis
add constraint pk_patient_diagnosis_d_id_p_id
primary key(d_id,p_id)
go


alter table Users. patient_diagnosis
add constraint fk1_patients_patient_diagnosis_p_id
foreign key(p_id)references Users.patients(patient_id)
go

alter table Users. patient_diagnosis
add constraint fk2_diagnosises_patient_diagnosis_d_id
foreign key(d_id) references session.diagnosises(diagnosis_id)
go

alter table session.persriptions
add appoint_id int
go

alter table session.persriptions 
add constraint fk_persriptions_appointments_appoint_id
foreign key(appoint_id) references appointments.appointments(appointments_id)
go
 alter table Users.patients
 add investgation   varbinary (max);

 go

 alter table session.diagnosises
 add c_investgation varbinary (max);

 go 
  alter table session.persriptions
  alter column dosage int null;
  go
  select * from  Users.patients;
  go

  select * from  session.diagnosises;
  select * from  Users.patient_diagnosis
  go


  SELECT *
FROM session.diagnosises AS d
INNER JOIN Users.patient_diagnosis AS pd
ON d.diagnosis_id = pd.d_id
WHERE pd.p_id =p_id;

DELETE FROM Users.patients;
 delete from Users.patients where patient_id =1; 
 select * from clinic90 ; 
 select * from test ;
 go 
 create table test2 (
 date date ,
 id int ,
 des varchar(500)
 );
 select * from test2;
 go 